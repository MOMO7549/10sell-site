globalThis.process ??= {}; globalThis.process.env ??= {};
const server = {};

export { server };
